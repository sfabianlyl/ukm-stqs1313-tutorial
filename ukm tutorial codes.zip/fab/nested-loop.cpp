#include<iostream>
#include<string>
using namespace std;

int main(){
	
//	for(int i=1;i<=5;i++){
//		
//		for(int j=1;j<=i;j++){
//			cout<<j;
////			system("pause");
//		}
//		
//		cout<<endl;
//	}

	char a= 'a' +1;
	int b=a;
	float c=a;
	string d="b";
	cout<<a<<endl<<b<<endl<<c<<endl<<c;
}
