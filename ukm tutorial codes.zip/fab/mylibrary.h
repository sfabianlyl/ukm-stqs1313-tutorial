#include <string>
#include "mylibrary.cpp"

int factorial (int);
char encode(char);
char decode(char);
string encode(string);
string decode(string);
